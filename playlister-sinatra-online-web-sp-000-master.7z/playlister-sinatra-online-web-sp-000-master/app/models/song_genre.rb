class SongGenre < ActiveRecord::Base
  def self.find_by_slug(slug)
    self.all.find {|object| object.slug == slug}
  end

  def slug
    name.gsub(" ", "-").downcase
  end
  belongs_to :song
  belongs_to :genre
end
